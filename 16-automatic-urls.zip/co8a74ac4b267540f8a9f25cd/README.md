# Extended Syntax - Automatic URLs
--- 

[My Channel](www.YouTube.com/CodingTutorials360)

www.YouTube.com/CodingTutorials360

`www.YouTube.com/CodingTutorials360 `