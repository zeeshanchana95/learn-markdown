# Extended Syntax - Tasks List
--- 

- [ ] Did you run the tests?
- [x] Did you lint the project?