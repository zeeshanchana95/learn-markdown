## Challenge: Introductory Paragraph

##### Step 1
Add an introductory paragraph about your subject of choice

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/5aznnppbg6d9uulbezyo.png)

Markdown allows us to write HTML in a quick and fluid way. 
We use this on the regular for our code reviews, comment sections and README files again and again.