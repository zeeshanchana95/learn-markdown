# Extended Syntax - Tables
--- 

| Left | Center | Right |
| :--- | :----: | ----: |
| 1    | 2      | 3     |