# 🖥 Markdown Course LIVE on Scrimba

![Markdown Logo](https://dev-to-uploads.s3.amazonaws.com/i/snq5gst9tw245shyavk2.png) 


![Alt Text](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/3grf1optgq8yqizp56ah.png)
---

## Challenge: Spice It Up

1. Add an image and/or a code block to your article.