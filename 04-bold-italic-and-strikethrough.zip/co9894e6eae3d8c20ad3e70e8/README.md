# Bold, Italic and Strikethrough

not bolded - **bold 1** __bold 2__

not italic - _italic 1_ *italic 2*

not strikethrough - ~~striked 1~~