# 🖥 Markdown Course LIVE on Scrimba

I personally have been really impressed with the screencast functionality. It has 3 main pieces which make it stand out:

1.  Pausing the screencast and having selectable code that can be ran and played with.
2.  File size being typically **1%** of a normal video file.
3.  The free availability of anyone who wants to use their screencasts for demos can and share them with their friends and colleagues. 

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/1xk1r22x5vvty1i62cav.png)

---

## Challenge: 3 Pieces of Information

1. Add a new supporting paragraph. 
2. Add a list with at least 3 pieces of information.