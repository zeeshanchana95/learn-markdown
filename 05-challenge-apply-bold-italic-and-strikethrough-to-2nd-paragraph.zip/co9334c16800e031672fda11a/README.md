# 🖥 Markdown Course LIVE on Scrimba

Markdown allows us to write HTML in a quick and fluid way. We use this on the regular for our code reviews, comment sections and README files again and again. 

At first glance the importance of **Markdown** may not seem all that important. You would be ~~right~~ wrong! _Readability_ in your PRs and being able to communicate your point clearly and cleanly is crucial. Its not uncommon for engineers to create documents ahead of time to their team members for future features on apps that support Markdown to get their point across!

## Challenge: 2nd Paragraph

##### Step 1
Add a 2nd paragraph to your article.

##### Step 2 
Bold something in either paragraphs.

##### Step 3
Italicize something in either paragraphs.

##### Step 4
Strikethrough something in either paragraphs.