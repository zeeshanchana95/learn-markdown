# 🖥 Markdown Course LIVE on Scrimba

#### About Me

As the author of this course I thought it might make sense to introduce myself. My name is  **Dylan Israel**.  I current work as a _Front End Engineer_ at Amazon. In my free time I run a [YouTube Channel](https://www.YouTube.com/CodingTutorials360 "My Channel") on software engineering.

I also run a podcast called Self-Taught or Not with my co-host Erik Hanchett. He also runs a YouTube channel called [Program with Erik](https://www.youtube.com/channel/UCshZ3rdoCLjDYuTR_RBubzw "Erik's Channel").

[![Podcast](https://dev-to-uploads.s3.amazonaws.com/i/6nm9s8h4jwndmap741xc.png)](https://www.selftaughtornot.com/episodes)

---
![Alt Text](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/ct68bkynz5q614xhwlw4.png)

---

## Challenge: About Yourself

1. Add a paragraph or two explaining who you are towards the end of the article.
2. Include one link on the page to something relevant.
3. Wrap an image with a link tag as well.
4. Use any of the Markdown you have learned along the way that makes sense.