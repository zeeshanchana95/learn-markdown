## Challenge: Creating Our Dev.to Article

# Solution

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/prnyk8ixsd9ab0mwilip.png)

# Markdown Course LIVE on Scrimba


##### Step 0
Create Dev.to account

##### Step 1
Login to Dev.to and click "Write a Post"

##### Step 2
Create an article title with an emoji on Dev.to on a technical subject or project from Scrimba
